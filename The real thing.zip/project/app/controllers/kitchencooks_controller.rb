class KitchencooksController < ApplicationController
  before_action :set_kitchencook, only: [:show, :edit, :update, :destroy]

  # GET /kitchencooks
  # GET /kitchencooks.json
  def index
    @kitchencooks = Kitchencook.all
  end

  # GET /kitchencooks/1
  # GET /kitchencooks/1.json
  def show
  end

  # GET /kitchencooks/new
  def new
    @kitchencook = Kitchencook.new
  end

  # GET /kitchencooks/1/edit
  def edit
  end

  # POST /kitchencooks
  # POST /kitchencooks.json
  def create
    @kitchencook = Kitchencook.new(kitchencook_params)

    respond_to do |format|
      if @kitchencook.save
        format.html { redirect_to @kitchencook, notice: 'Kitchencook was successfully created.' }
        format.json { render :show, status: :created, location: @kitchencook }
      else
        format.html { render :new }
        format.json { render json: @kitchencook.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /kitchencooks/1
  # PATCH/PUT /kitchencooks/1.json
  def update
    respond_to do |format|
      if @kitchencook.update(kitchencook_params)
        format.html { redirect_to @kitchencook, notice: 'Kitchencook was successfully updated.' }
        format.json { render :show, status: :ok, location: @kitchencook }
      else
        format.html { render :edit }
        format.json { render json: @kitchencook.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /kitchencooks/1
  # DELETE /kitchencooks/1.json
  def destroy
    @kitchencook.destroy
    respond_to do |format|
      format.html { redirect_to kitchencooks_url, notice: 'Kitchencook was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_kitchencook
      @kitchencook = Kitchencook.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def kitchencook_params
      params.require(:kitchencook).permit(:cook_id, :kitchen_id)
    end
end
