module CooksHelper
end
