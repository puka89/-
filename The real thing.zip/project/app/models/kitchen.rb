class Kitchen < ApplicationRecord

	has_many :kitchencooks
	has_many :cooks, through: :kitchencooks

  	validates :name, uniqueness: true

end
