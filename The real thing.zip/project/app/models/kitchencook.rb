class Kitchencook < ApplicationRecord

	belongs_to :kitchen
	belongs_to :cook

	validate :check

	validate do
		t = Cook.find(self.cook_id)
		s = Kitchen.find(self.kitchen_id)

		if t.score < s.stars
			errors.add(:base, "Problem")
		end
	end

	private

	def check
		count =	Kitchencook.where(kitchen_id: self.kitchen_id).count
		if count >= Kitchencook.kitchen.cooks
			errors.add(:base, "Problem")
		end
	end

end
