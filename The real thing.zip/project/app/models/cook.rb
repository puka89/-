class Cook < ApplicationRecord

	has_many :kitchencooks
	has_many :kitchens, through: :kitchencooks

	validates :name, uniqueness: true
end
