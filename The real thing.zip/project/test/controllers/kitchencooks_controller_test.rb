require 'test_helper'

class KitchencooksControllerTest < ActionDispatch::IntegrationTest
  setup do
    @kitchencook = kitchencooks(:one)
  end

  test "should get index" do
    get kitchencooks_url
    assert_response :success
  end

  test "should get new" do
    get new_kitchencook_url
    assert_response :success
  end

  test "should create kitchencook" do
    assert_difference('Kitchencook.count') do
      post kitchencooks_url, params: { kitchencook: { cook_id: @kitchencook.cook_id, kitchen_id: @kitchencook.kitchen_id } }
    end

    assert_redirected_to kitchencook_url(Kitchencook.last)
  end

  test "should show kitchencook" do
    get kitchencook_url(@kitchencook)
    assert_response :success
  end

  test "should get edit" do
    get edit_kitchencook_url(@kitchencook)
    assert_response :success
  end

  test "should update kitchencook" do
    patch kitchencook_url(@kitchencook), params: { kitchencook: { cook_id: @kitchencook.cook_id, kitchen_id: @kitchencook.kitchen_id } }
    assert_redirected_to kitchencook_url(@kitchencook)
  end

  test "should destroy kitchencook" do
    assert_difference('Kitchencook.count', -1) do
      delete kitchencook_url(@kitchencook)
    end

    assert_redirected_to kitchencooks_url
  end
end
