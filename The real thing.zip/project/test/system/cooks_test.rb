require "application_system_test_case"

class CooksTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit cooks_url
  #
  #   assert_selector "h1", text: "Cook"
  # end
end
