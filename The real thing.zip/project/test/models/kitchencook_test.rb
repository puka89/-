require 'test_helper'

class KitchencookTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
