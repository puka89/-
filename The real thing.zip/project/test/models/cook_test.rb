require 'test_helper'

class CookTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
