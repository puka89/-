class CreateKitchens < ActiveRecord::Migration[5.1]
  def change
    create_table :kitchens do |t|
      t.string :name
      t.integer :cooks
      t.integer :stars

      t.timestamps
    end
  end
end
